<?php $__env->startSection('content'); ?>
<div class="wg-box mt-5">
    <h3>Tracking Order #<?php echo e($order->id); ?> - <?php echo e($order->user->name); ?></h3>

    <form method="POST" action="<?php echo e(route('admin.orders.track.store', $order->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="row ">
            <div class="col-md-3">
                <!-- <input type="text" name="status" value="<?php echo e($order->status); ?>" placeholder="Status" class="form-control" required> -->
                <label for="">Status</label>
                <select name="order_status" id="order_status">
                    <option value="ordered" <?php echo e($order->status == 'ordered' ? "selected":""); ?>>Ordered</option>
                    <option value="delivered" <?php echo e($order->status == 'delivered' ? "selected":""); ?>>Delivered</option>
                    <option value="canceled" <?php echo e($order->status == 'canceled' ? "selected":""); ?>>Canceled</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="">Location</label>
                <input type="text" name="location" placeholder="Location" value="<?php echo e($order->address); ?>" class="form-control">
            </div>
            <div class="col-md-3">
                <label for="">State</label>
                <input type="text" name="state" placeholder="State" value="<?php echo e($order->state); ?>" class="form-control">
            </div>
            <div class="col-md-3">
                <label for="">Date</label>
                <input type="datetime-local" name="scan_time" class="form-control" required>
            </div>

        </div><br>
        <div class="col-md-6">
            <button type="submit" class="btn btn-primary tf-button w208">Add Scan</button>
        </div>
    </form>

    <h5>Scan History</h5>
    <ul class="list-group">
        <?php $__currentLoopData = $scans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
            <strong><?php echo e($scan->status); ?></strong> –
            <?php echo e($scan->location); ?> (<?php echo e($scan->state); ?>) –
            <?php echo e(\Carbon\Carbon::parse($scan->scan_time)->format('d M Y, h:i A')); ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravelecommerce\resources\views/admin/orders/track.blade.php ENDPATH**/ ?>