<?php $__env->startSection('content'); ?>
<style>
    .card {
        background: white;
        padding: 20px;
        margin: 50px auto;
        width: 600px;
        border-radius: 10px;
    }

    .status-bar {
        display: flex;
        justify-content: space-between;
        margin-bottom: 30px;
    }

    .step {
        text-align: center;
        flex: 1;
        color: #999;
    }

    .step.active {
        color: green;
        font-weight: bold;
    }

    .scan-entry {
        border-left: 2px solid #ccc;
        margin: 10px 0;
        padding-left: 10px;
    }
</style>
<main class="pt-90" style="padding-top: 0px;">
    <div class="mb-4 pb-4"></div>
    <section class="my-account container">
        <h2 class="page-title">Orders Tracking</h2>
        <div class="row">
            <div class="col-lg-2">
                <?php echo $__env->make('user.account-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="card">
                <h3>Tracking Order #<?php echo e($order->id); ?></h3>
                <p>User: <?php echo e($order->user->name); ?> (<?php echo e($order->user->email); ?>)</p>

                <?php
                $statusSteps = [
                'Processing' => $order->created_at,
                'Shipped' => $order->shipped_date,
                'Out for Delivery' => $order->out_for_delivery_date,
                'Canceled' => $order->canceled_date,
                'Delivered' => $order->delivered_date,
                ];

                // Filter only available statuses
                $filteredSteps = collect($statusSteps)->filter();

                // Group by date
                $groupedByDate = $filteredSteps->groupBy(fn($timestamp) =>
                \Carbon\Carbon::parse($timestamp)->format('d M Y')
                );
                ?>

                <div class="status-bar">
                    <?php $__currentLoopData = array_keys($statusSteps); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($statusSteps[$step]): ?>
                    <div class="step active">
                        ✔ <?php echo e($step); ?>

                    </div>
                    <?php else: ?>
                    <div class="step">
                        <?php echo e($step); ?>

                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php $__currentLoopData = $groupedByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $timestamps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4><?php echo e($date); ?></h4>
                <?php $__currentLoopData = $timestamps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timestamp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $stepName = $filteredSteps->first(function($value, $key) use ($timestamp) {
                return $value == $timestamp;
                });

                $stepLabel = $filteredSteps->search($timestamp); // returns status name

                $location = $order->address ?? 'N/A';
                $state = $order->state ?? '';
                ?>
                <div class="scan-entry">
                    <strong><?php echo e(\Carbon\Carbon::parse($timestamp)->format('h:i A')); ?></strong><br>
                    <?php echo e($stepLabel); ?><br>
                    <em><?php echo e($location); ?> (<?php echo e($state); ?>)</em>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravelecommerce\resources\views/user/order-tracking.blade.php ENDPATH**/ ?>