<!DOCTYPE html>
<html>
<head>
    <title>Stripe Checkout</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Tailwind CSS CDN (optional) -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex justify-center items-center min-h-screen">
        <div class="bg-white shadow-md rounded p-8 max-w-md w-full">
            <h2 class="text-2xl font-bold mb-4 text-center">Stripe Payment</h2>

            <?php if(session('error')): ?>
                <div class="bg-red-100 text-red-800 p-4 rounded mb-4">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('payment.checkout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <p class="mb-4">Amount: $10.00</p>
                <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700 transition">
                    Pay with Stripe
                </button>
            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH E:\Xampp\htdocs\laravelecommerce\resources\views/payment.blade.php ENDPATH**/ ?>