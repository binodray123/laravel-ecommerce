<?php $__env->startSection('content'); ?>
<main class="py-5 text-center">
    <h2>🎉 Payment Successful</h2>
    <p>Your order has been placed successfully.</p>
    <a href="<?php echo e(route('home.index')); ?>" class="btn btn-success mt-3">Continue Shopping</a>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravelecommerce\resources\views/payment-success.blade.php ENDPATH**/ ?>